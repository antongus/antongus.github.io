stm32tpl
========

STM32 C++ Template Peripheral Library

Released under MIT License.

See [https://github.com/antongus/stm32tpl](https://github.com/antongus/stm32tpl) for latest version.
