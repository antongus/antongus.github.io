#ifndef UTIL_H_INCLUDED
#define UTIL_H_INCLUDED
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

char HexChar(char ch);
void strreverse(char* begin, char* end);
char *str_upr(char *s);
char* itoa(int value, char* s, int base);
long small_atoi(char * s);
double small_atof(char * s);
uint32_t small_atoh(char * s);

char small_isxdigit (unsigned char c);
uint8_t small_isspace (char c);
char * trim(char *p);
char * GetToken(char *s, char **last);
char * GetToken2(char *s, char **last, const char * dlims);
char * get_float_token(double* f, char **last);
char * get_u16_token(uint16_t* Int, char **last);
char * get_int_token(int* Int, char **last);
char * get_byte_token(uint8_t* c, char **last);
void pad(char * s, int width, char padder);

#ifdef __cplusplus
}
#endif

#endif
