/**
*  @file VirtualProcess.h
*
*  Created on: 15.11.2012
*  Copyright (c) Anton Gusev aka AHTOXA
**/

#ifndef VIRTUALPROCESS_H_
#define VIRTUALPROCESS_H_

#include <scmRTOS.h>

namespace OS
{

class BaseVirtualProcess : public TBaseProcess, public TKernelAgent
{
public:
	INLINE_PROCESS_CTOR BaseVirtualProcess(
			stack_item_t * StackPoolEnd
			, TPriority pr
		#if scmRTOS_DEBUG_ENABLE == 1
			, stack_item_t * aStackPool
		#endif
			) : TBaseProcess(
					StackPoolEnd
					, pr
					, launch_exec
				#if scmRTOS_DEBUG_ENABLE == 1
					, aStackPool
				#endif
				)
	{
	}
protected:
	OS_PROCESS virtual void exec() { for(;;){} };
private:
	OS_PROCESS static void launch_exec()
	{
		for(;;) // eliminate compiler warning
		{
			TBaseProcess* base = const_cast<TBaseProcess*>(get_proc(cur_proc_priority()));
//			TBaseProcess* base = cur_proc();  // private!
			BaseVirtualProcess* proc = static_cast<BaseVirtualProcess*>(base);
			proc->exec();
		}
	}
};


template<TPriority pr, size_t stack_size>
class VirtualProcess : public BaseVirtualProcess
{
public:
	INLINE_PROCESS_CTOR VirtualProcess()
		: BaseVirtualProcess(&Stack[stack_size/sizeof(stack_item_t)]
		, pr
#if scmRTOS_DEBUG_ENABLE == 1
		, Stack
#endif
		)
	{
	}
private:
	stack_item_t Stack[stack_size/sizeof(stack_item_t)];
};

} // namespace OS


#endif /* VIRTUALPROCESS_H_ */
