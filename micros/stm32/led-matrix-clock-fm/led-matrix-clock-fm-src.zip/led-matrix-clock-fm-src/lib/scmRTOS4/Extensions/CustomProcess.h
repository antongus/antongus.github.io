/**
*  @file CustomProcess.h
*
*  Created on: 13.11.2012
*  Copyright (c) Anton Gusev aka AHTOXA
**/

#ifndef CUSTOMPROCESS_H_
#define CUSTOMPROCESS_H_

#include <scmRTOS.h>

namespace OS
{


template<typename ExecType, TPriority pr, size_t stack_size>
class CustomProcess : public TBaseProcess
{
public:
	INLINE_PROCESS_CTOR CustomProcess();

#if scmRTOS_PROCESS_RESTART_ENABLE == 1
	INLINE void terminate();
#endif


private:
	stack_item_t Stack[stack_size/sizeof(stack_item_t)];
};

template<typename ExecType, TPriority pr, size_t stack_size>
OS::CustomProcess<ExecType, pr, stack_size>::CustomProcess() : TBaseProcess( &Stack[stack_size/sizeof(stack_item_t)]
													 , pr
													 , reinterpret_cast<void (*)()>(&ExecType::exec)
												 #if scmRTOS_DEBUG_ENABLE == 1
													 , Stack
												 #endif
													 )
{
}

#if scmRTOS_PROCESS_RESTART_ENABLE == 1
template<TPriority pr, size_t stack_size>
void OS::CustomProcess<pr, stack_size>::terminate()
{
	TCritSect cs;

	reset_controls();
	init_stack_frame( &Stack[stack_size/sizeof(stack_item_t)]
					  , reinterpret_cast<void (*)()>(exec)
				  #if scmRTOS_DEBUG_ENABLE == 1
					  , Stack
				  #endif
					);
}
#endif // scmRTOS_RESTART_ENABLE

} // namespace OS

#endif /* CUSTOMPROCESS_H_ */
