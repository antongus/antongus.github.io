/**
*  @file TemplatedProc.h
*
*  Created on: 17.11.2012
*  Copyright (c) Anton Gusev aka AHTOXA
**/

#ifndef TEMPLATEDPROC_H_
#define TEMPLATEDPROC_H_

#include <scmRTOS.h>

namespace OS
{

template <
	class ProcClass,
	void (ProcClass::*execFunc)(),
	TPriority pr,
	size_t stack_size
	>
class FuncProcess : public TBaseProcess
{
public:
	INLINE_PROCESS_CTOR FuncProcess() :TBaseProcess( &Stack[stack_size/sizeof(stack_item_t)]
	 													 , pr
	 													 , launch_exec
	 												 #if scmRTOS_DEBUG_ENABLE == 1
	 													 , Stack
	 												 #endif
	 													 )
	{

	}
private:
	static void launch_exec()
	{
		BaseVirtualProcess* proc = reinterpret_cast<BaseVirtualProcess*>(const_cast<TBaseProcess*>(get_proc(cur_proc_priority())));
//		BaseVirtualProcess* proc = reinterpret_cast<BaseVirtualProcess*>(cur_proc());
		proc->exec();
	};
	stack_item_t Stack[stack_size/sizeof(stack_item_t)];
};

} // namespace OS

#endif /* TEMPLATEDPROC_H_ */
