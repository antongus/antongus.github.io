#include "hw.h"

RtcModuleLSE rtc;
KeyboardType kbd;
TMax Max;
FmTuner tuner;
