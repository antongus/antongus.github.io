#ifndef TIMER0_H_INCLUDED
#define TIMER0_H_INCLUDED
#include "common.h"

extern void timer0_init(void);
extern void delay_ms(uint8_t ms);


#endif // TIMER0_H_INCLUDED
