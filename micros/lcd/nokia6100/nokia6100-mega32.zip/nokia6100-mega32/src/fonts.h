
extern uint8_t comic_18[];
extern uint8_t verdana16[];
