/**
*  @file nokia610.h
*
*  Created on: 30.01.2011
*  Copyright (c) 2010 by Anton Gusev aka AHTOXA
**/

#ifndef NOKIA610_H_
#define NOKIA610_H_


#endif /* NOKIA610_H_ */
