#ifndef TA7291_H_INCLUDED
#define TA7291_H_INCLUDED
#include "common.h"

void ta7291_init(void);
void ta7291_set_speed(int speed);
int ta7291_get_speed(int speed);

#endif // TA7291_H_INCLUDED
