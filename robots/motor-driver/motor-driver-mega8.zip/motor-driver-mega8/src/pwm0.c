#include <avr/io.h>
#include <avr/interrupt.h>
#include "pwm0.h"

#define OC1A_PIN    B, 1, H
//#define PWM_WIDTH	(128)
#define PWM_WIDTH	(256)
#define PWM_INVERSE

void pwm0_init(void)
{
	off(OC1A_PIN);
	direct(OC1A_PIN, O);

	TCCR1A |= _BV(COM1A0);  // Set OC1A on compare match, clear OC1A at TOP
//	TCCR1A &= ~_BV(COM1A0);	// Clear OC1A on compare match, set OC1A at TOP
	TCCR1A |= _BV(COM1A1);

	TCCR1A &= ~_BV(WGM10);
	TCCR1A |= _BV(WGM11);
	TCCR1B |= _BV(WGM12);
	TCCR1B |= _BV(WGM13);

	ICR1 = PWM_WIDTH;

	pwm_set(0);

	TCCR1B |= _BV(CS10);
}

static uint8_t pwm_value;

inline void pwm_set(uint8_t value)
{
	pwm_value = value;
//	if (pwm_value > PWM_WIDTH) pwm_value = PWM_WIDTH;
#ifdef PWM_INVERSE
	value = PWM_WIDTH - pwm_value;
	if (!value) value = 1;
#else
	value = pwm_value;
	if (value == PWM_WIDTH) value = PWM_WIDTH - 1;
#endif
	OCR1A = value;
}

inline void pwm_inc(void)
{
	pwm_set(pwm_value + 1);
}

inline void pwm_dec(void)
{
	if (pwm_value)
		pwm_set(pwm_value - 1);
}

inline uint8_t pwm_get(void)
{
	return pwm_value;
}

