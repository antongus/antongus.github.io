#ifndef TIMER0_H_INCLUDED
#define TIMER0_H_INCLUDED
#include "common.h"

#define ENC_NONE		(0)
#define ENC_LEFT		(1)
#define ENC_RIGHT		(2)
#define ENC_PRESS		(3)
#define ENC_LONG		(4)

extern volatile uint8_t ms_ticks_uint8_t;
extern uint8_t encoder_keypressed(void);
extern uint8_t encoder_getchar(void);

extern void timer0_init(void);
extern void delay_ms(uint8_t ms);
extern void delay_s(uint8_t s);


#endif // TIMER0_H_INCLUDED
