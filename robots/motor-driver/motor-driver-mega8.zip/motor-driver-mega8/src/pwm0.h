#ifndef PWM0_H_INCLUDED
#define PWM0_H_INCLUDED
#include "common.h"

extern void pwm0_init(void);
extern inline void pwm_set(uint8_t value);
extern inline uint8_t pwm_get(void);
extern inline void pwm_inc(void);
extern inline void pwm_dec(void);


#endif // PWM0_H_INCLUDED
