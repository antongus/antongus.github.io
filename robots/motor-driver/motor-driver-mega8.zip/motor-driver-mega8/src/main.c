#include <avr/io.h>
#include <avr/interrupt.h>
#include "common.h"

#include "pwm0.h"
#include "timer0.h"
#include "ta7291.h"

int sp = 0;
int step = 1;
typedef enum
{
	DOWN = 0,
	UP
}direction;

direction dir = UP;

int main (void)
{
	timer0_init();
	pwm0_init();
	ta7291_init();
	sei();

	for(;;)
	{
		delay_ms(20);

		if (sp > 250)
			ta7291_set_speed(250);
		else if (sp < -250)
			ta7291_set_speed(-250);
		else
			ta7291_set_speed(sp);

		if (dir)
		{
			sp += step;
			if (sp > 500)
				dir = DOWN;
		}
		else
		{
			sp -= step;
			if (sp < -500)
			{
				dir = UP;
				step += 1;
			}
		}
	}

	return 0;
}

