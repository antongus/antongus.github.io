#ifndef COMMON_H_INCLUDED
#define COMMON_H_INCLUDED
#include "macros.h"
#include <stdint.h>

#define	FALSE			(0)
#define	TRUE			(!FALSE)

// project/system dependent defines

// CPU clock speed
//#define F_CPU			16000000               		// 16MHz processor
//#define F_CPU			14745000               		// 14.745MHz processor
//#define F_CPU			14318000               		// 14.293MHz processor
//#define F_CPU			14293000               		// 14.293MHz processor
//#define F_CPU			12000000               		// 12MHz processor
#define F_CPU			8000000               		// 8MHz processor
//#define F_CPU			7372800               		// 7.37MHz processor
//#define F_CPU			4000000               		// 4MHz processor
//#define F_CPU			3686400               		// 3.69MHz processor

#endif	//	COMMON_H_INCLUDED
