#include <avr/io.h>
#include <avr/interrupt.h>
#include "ta7291.h"
#include "pwm0.h"

#define TA7291_IN1	D, 6, H
#define TA7291_IN2	D, 7, H

static int ta7291_speed = 0;

void ta7291_init(void)
{
	off(TA7291_IN1);
	direct(TA7291_IN1, O);
	off(TA7291_IN2);
	direct(TA7291_IN2, O);

}

void ta7291_set_speed(int speed)
{
	ta7291_speed = speed;
	if (speed == 0)
	{
		off(TA7291_IN1);
		off(TA7291_IN2);
	}
	else if (speed > 0)
	{
		off(TA7291_IN1);
		on(TA7291_IN2);
		pwm_set(speed);
	}
	else
	{
		speed = -speed;
		off(TA7291_IN2);
		on(TA7291_IN1);
		pwm_set(speed);
	}
}

int ta7291_get_speed(int speed)
{
	return ta7291_speed;
}

